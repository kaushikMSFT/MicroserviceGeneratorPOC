﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp2.Contracts
{
    public interface IReader
    {
        public void Read();
       
    }
}
