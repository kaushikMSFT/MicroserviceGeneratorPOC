﻿using EnvDTE;
using EnvDTE80;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO.Packaging;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Specify a name for your top-level folder.
            string folderName = @"c:\Microservices"; ////hardcoded as of now
            string projectName = textBox1.Text;
            //To create a string that specifies the path to a subfolder under your
            // top-level folder, add a name for the subfolder to folderName.
            string pathString = System.IO.Path.Combine(folderName, projectName);

            // You can write out the path name directly instead of using the Combine
            // method. Combine just makes the process easier.
            // string pathString2 = @"c:\Top-Level Folder\SubFolder2";

            // You can extend the depth of your path if you want to.
            string pathStringWeb = System.IO.Path.Combine(pathString, "Web");
            string pathStringGateway = System.IO.Path.Combine(pathString, "Gateway");
            string pathStringCore = System.IO.Path.Combine(pathString, "Core");
            string pathStringInfrastructure = System.IO.Path.Combine(pathString, "Infrastructure");
            string pathStringApplication = System.IO.Path.Combine(pathString, "Application");

            string pathStringTest = System.IO.Path.Combine(pathString, "Test");
            string pathStringExternalBin = System.IO.Path.Combine(pathString, "ExternalBin");
            int reader = 1;
            string textReader = "TextReader";
            string csvReader = "CSVReader";
            //Create the subfolder. You can verify in File Explorer that you have this
            // structure in the C: drive.
            //    Local Disk (C:)
            //        Top-Level Folder
            //            SubFolder

            System.IO.Directory.CreateDirectory(pathString);
            System.IO.Directory.CreateDirectory(pathStringCore);
            System.IO.Directory.CreateDirectory(pathStringWeb);
            System.IO.Directory.CreateDirectory(pathStringInfrastructure);
            System.IO.Directory.CreateDirectory(pathStringGateway);
            System.IO.Directory.CreateDirectory(pathStringTest);
            System.IO.Directory.CreateDirectory(pathStringExternalBin);

            //// PATH
            //string commonName = "ConsoleAppProg";
            //string csPrjPath = $"C:\\TestCreateProject\\{commonName}";
            //Assembly loadedAssembly = null;
            //try
            //{
            //    loadedAssembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(@"C:\Users\Windows\.nuget\packages\envdte\16.10.31320.204\lib\netstandard2.0\EnvDTE.dll");
            //       // @"C: \Users\Windows\.nuget\packages\envdte80\17.0.0 - previews - 3 - 31605 - 261\lib\netcoreapp3.1\envdte80.dll)";
            //}
            //catch
            //{

            //}
            // // SOLUTION INITIALIZATION
            // DTE2 dte = (DTE2)GetService(typeof(DTE));
            // //Type type=Package.GetGlobalService(typeof(DTE)) as DTE2;
            // //Type type = Type.GetType("EnvDTE._DTE");// FromProgID("VisualStudio.DTE2.1.0");
            // Type type=loadedAssembly.GetType("EnvDTE._DTE");
            //// EnvDTE.DTE dte = Activator.CreateInstance(type, true) as DTE2;
            // Solution2 sln = (Solution2)dte.Solution;

            // string csProjectTemplatePath = sln.GetProjectTemplate("ClassLibraryTemplate.zip", "CSharp");

            // // SOLUTION AND PROJECT CREATION
            // sln.Create(csPrjPath, commonName);
            // sln.SaveAs(commonName + ".sln");
            // sln.AddFromTemplate(csProjectTemplatePath, $"{csPrjPath}\\{commonName}", commonName, false);
            string[] commands = new string[11];
            commands[0] = String.Format("dotnet new sln --name {0} -o {1}", projectName, pathString);
            commands[1] = String.Format(@"copy Externalbin\*.* {0}\externalbin ", pathString);
            commands[2] = String.Format(@"nuget sources Add -Name 'MyServer' -Source {0}", pathStringExternalBin);
            commands[3] = String.Format("dotnet new webapi --framework netcoreapp3.1  -n {0}.Web -o {1} ", projectName, pathStringWeb);
            commands[4] = String.Format("dotnet new classlib --framework netcoreapp3.1  -n {0}.Core -o {1}", projectName, pathStringCore);
            commands[5] = String.Format("dotnet new classlib --framework netcoreapp3.1  -n {0}.Application -o {1}", projectName, pathStringCore);
            commands[6] = String.Format("dotnet new classlib --framework netcoreapp3.1  -n {0}.Infrastructure -o {1}", projectName, pathStringInfrastructure);
            commands[7] = String.Format("dotnet new classlib --framework netcoreapp3.1  -n {0}.Gateway -o {1}", projectName, pathStringGateway);
            commands[8] = String.Format("dotnet new mstest --framework netcoreapp3.1  -n {0}.Test -o {1}", projectName, pathStringTest);
            commands[9] = String.Format(@"dotnet sln {6}\{0}.sln add {1}\{0}.Web.csproj {2}\{0}.Core.csproj    {3}\{0}.Test.csproj {4}\{0}.Infrastructure.csproj  {5}\{0}.Gateway.csproj", projectName, pathStringWeb, pathStringCore,  pathStringTest, pathStringInfrastructure, pathStringGateway, pathString);
            //  {6}/{0}.Gateway.csproj
            
            commands[10]= String.Format(@"dotnet add {1}\{0}.Web.csproj package {3} --source {2} -f netcoreapp3.1", projectName, pathStringWeb, pathStringExternalBin , reader==1?csvReader:textReader   );
            // dotnet new sln --name mysln1 -o c:\test--force & dotnet new classlib - n myclasslib1 - o c:\test--force

            //var pp = new ProcessStartInfo("cmd.exe", string.Format("/C {0} ",  commands[1]))
            //{
            //    CreateNoWindow = true,
            //    UseShellExecute = false,
            //    WorkingDirectory = "C:\\",
            //};

            var pp = new ProcessStartInfo("cmd.exe", string.Format("/C {0} & {1} &  {2} & {3} & {4} & {5} & {6} & {7} & {8} & {9} & {10}", commands[0], commands[1], commands[2], commands[3], commands[4], commands[5], commands[6], commands[7], commands[8], commands[9], commands[10]))
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                WorkingDirectory = "C:\\",
            };
            var process = System.Diagnostics.Process.Start(pp);
            //var pp1 = new ProcessStartInfo("cmd.exe", "/C" + "dotnet new classlib --framework netcoreapp3.1 -o "+ projectName + ".Persistence & dotnet sln " + projectName +".sln add PathToTheCsProjFile ")
            //{
            //    CreateNoWindow = true,
            //    UseShellExecute = false,
            //    WorkingDirectory = "C:\\",
            //};                      
            //var process1 = System.Diagnostics.Process.Start(pp1);
            
            

            MicroserviceTemplate template = new MicroserviceTemplate(projectName);
            string content = template.TransformText();
            //System.IO.File.WriteAllText(string.Format("{0} \\  {1}", pathStringWeb, "Microservice.cs"), content);
            TextInfo tInfo = new CultureInfo("en-US", false).TextInfo;
            string projectname_camel = tInfo.ToTitleCase(projectName);
            process.WaitForExit(5000);
            process.Close();
            System.Threading.Thread.Sleep(5000);
            System.IO.File.WriteAllText(string.Format(@"{0}\{1}Controller.cs", pathStringWeb+"\\Controllers", projectname_camel), content);

            StartupTemplate template2 = new StartupTemplate(2);
            content = template2.TransformText();
            tInfo = new CultureInfo("en-US", false).TextInfo;
            projectname_camel = tInfo.ToTitleCase(projectName);
            System.Threading.Thread.Sleep(5000);
            System.IO.File.WriteAllText(string.Format(@"{0}\Startup.cs", pathStringWeb , projectname_camel), content);


        }


    }
}
