﻿using System;
using System.Collections.Generic;
using System.Text;
using WindowsFormsApp2.Contracts;

namespace WindowsFormsApp2.Impl
{
    public class CSVReaderImpl : IReader
    {
        public void Read()
        {
            CSVReader.Reader cSVReader = new CSVReader.Reader();
            cSVReader.Read();
        }
    }
}
