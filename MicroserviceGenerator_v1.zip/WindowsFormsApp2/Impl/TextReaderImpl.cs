﻿using System;
using System.Collections.Generic;
using System.Text;
using WindowsFormsApp2.Contracts;

namespace WindowsFormsApp2.Impl
{
    class TextReaderImpl : IReader
    {
        public void Read()
        {
            TextReader.TextReader textReader = new TextReader.TextReader();
            textReader.Readme();
        }
    }
}
