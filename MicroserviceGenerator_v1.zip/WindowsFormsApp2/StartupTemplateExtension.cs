﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp2
{
    public partial class StartupTemplate
    {
        private int _reader = 0;
        //private string _modelNamespace_camel = String.Empty;
        public StartupTemplate(int readerImpl)
        {
            _reader = readerImpl;
        }
    }
}
