﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp2
{
    public partial class MicroserviceTemplate
    {
        private string _modelNamespace = String.Empty;
        //private string _modelNamespace_camel = String.Empty;
        public MicroserviceTemplate(string modelNamespace)
        {
            _modelNamespace = modelNamespace;
        }
    }
}
